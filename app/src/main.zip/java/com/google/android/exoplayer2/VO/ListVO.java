package com.google.android.exoplayer2.VO;

public class ListVO {
    private String idx;
    private String content;
    private String title_name;
    private String img_name;
    private String tot_time;
    private String file_name;
    private String uri;
    private String file_down_yn;
    private String before;
    private String favorite_yn;
    private String kor_script_yn;
    private String foreign_script_yn;
    private String lang_type;

    public String getIdx() {
        return idx;
    }

    public void setIdx(String idx) {
        this.idx = idx;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTitle_name() {
        return title_name;
    }

    public void setTitle_name(String title_name) {
        this.title_name = title_name;
    }

    public String getImg_name() {
        return img_name;
    }

    public void setImg_name(String img_name) {
        this.img_name = img_name;
    }

    public String getTot_time() {
        return tot_time;
    }

    public void setTot_time(String tot_time) {
        this.tot_time = tot_time;
    }

    public String getFile_name() {
        return file_name;
    }

    public void setFile_name(String file_name) {
        this.file_name = file_name;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public void setFile_down_yn(String file_down_yn) {
        this.file_down_yn = file_down_yn;
    }

    public String getFile_down_yn() {
        return file_down_yn;
    }

    public void setBefore(String before) {
        this.before = before;
    }

    public String getBefore() {
        return before;
    }

    public void setFavorite_yn(String favorite_yn) {
        this.favorite_yn = favorite_yn;
    }

    public String getFavorite_yn() {
        return favorite_yn;
    }

    public void setKor_script_yn(String kor_script_yn) {
        this.kor_script_yn = kor_script_yn;
    }

    public String getKor_script_yn() {
        return kor_script_yn;
    }

    public void setForeign_script_yn(String foreign_script_yn) {
        this.foreign_script_yn = foreign_script_yn;
    }

    public String getForeign_script_yn() {
        return foreign_script_yn;
    }

    public void setLang_type(String lang_type) {
        this.lang_type = lang_type;
    }

    public String getLang_type() {
        return lang_type;
    }
}
