/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.android.exoplayer2.demo;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RemoteViews;
import android.widget.TextView;
import android.widget.Toast;


import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.VO.ListVO;
import com.google.android.exoplayer2.auth.AuthCheckShowActivity;
import com.google.android.exoplayer2.dialog.CommonCancelDialog;
import com.google.android.exoplayer2.dialog.CommonDialog;
import com.google.android.exoplayer2.dialog.CommonPreDataDialog;
import com.google.android.exoplayer2.nw.JoinWebAsyncTask;
import com.google.android.exoplayer2.nw.NotificationReceiver;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {

    public static String host = "http://ilove14.cafe24.com/ESTD/ContentsList.php";

    MainActivity mainActivity;

    CommonCancelDialog cancelYnDialog;
    CommonPreDataDialog commonPreDataDialog;

    LinearLayout close;
    CommonDialog dialog;

    ProgressDialog progressDialog;
    RecyclerView rv;
    public static SimpleStringRecyclerViewAdapter adapter;
    SwipeRefreshLayout layout_order;

    public Button b_more;
    int page = 1;

    /************************* onCreate *************************/
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_list);
        mainActivity = this;

        close = (LinearLayout) findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        rv = (RecyclerView) findViewById(R.id.point_list);
        layout_order = (SwipeRefreshLayout) findViewById(R.id.layout_order);

        setupRecyclerView(rv);

        b_more = (Button) findViewById(R.id.b_more);
        b_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ++page;
                try {
                    //JoinWebAsyncTask boardAsyncTask = new JoinWebAsyncTask(PointHistotyListActivity.this, "getMyPointList");
                    //boardAsyncTask.execute(MainActivity.host, "getMyPointList," + page + "," + getDivNo());

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        layout_order.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                b_more.setText("더보기");
                try {

                    adapter.clear();
                    JoinWebAsyncTask boardAsyncTask = new JoinWebAsyncTask(MainActivity.this, "getStudyList");
                    boardAsyncTask.execute(MainActivity.host, "token=12345&UUID_KEY=" + getDevicesUUID(), "getStudyList");

                } catch (Exception e) {
                    e.printStackTrace();
                }
                layout_order.setRefreshing(false);

            }
        });

        registerReceiver(broadNetwork, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        if (getIntent() != null) {
            processIntent(getIntent());
        }

        //setNoti();
    }

    String pre_idx = "";
    String pre_number_int = "";
    String pre_currentPosition = "";

    public void getPreData() {
        SharedPreferences sf = getSharedPreferences("EnglishMp3CurrentData", 0);
        String currentPosition = sf.getString("currentPosition", "");
        String idx = sf.getString("idx", "");
        String number_int = sf.getString("number_int", "");

        Log.d("LOGDA_CURRENT", "getPreData current postion = " + currentPosition + "  number_int = " + number_int);

        if (idx != null && !idx.equals("") && number_int != null && !number_int.equals("")) {
            pre_idx = idx;
            pre_number_int = number_int;
            pre_currentPosition = currentPosition;
            commonPreDataDialog = new CommonPreDataDialog(mainActivity, continue_play);
            commonPreDataDialog.show();
        }
    }


    public View.OnClickListener continue_play = new View.OnClickListener() {
        public void onClick(View v) {
            commonPreDataDialog.dismiss();
            Intent i = new Intent(MainActivity.this, PlayerSpeedActivity.class);
            i.putExtra("uuid", getDevicesUUID());
            i.putExtra("pre_idx", pre_idx);
            i.putExtra("pre_currentPosition", pre_currentPosition);
            i.putExtra("pre_number_int", pre_number_int);
            startActivity(i);
        }
    };


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void setNoti() {

        Log.d("LOGDA", "setNoti div_no = " + getDivNo());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannelGroup group1 = new NotificationChannelGroup("channel_group_id", "channel_group_name");
            notificationManager.createNotificationChannelGroup(group1);
            NotificationChannel notificationChannel = new NotificationChannel("channel_id", "channel_name", NotificationManager.IMPORTANCE_DEFAULT);
            notificationChannel.setDescription("channel description");
            notificationChannel.setGroup("channel_group_id");
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.GREEN);
            notificationChannel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            notificationManager.createNotificationChannel(notificationChannel);
        }

        int notificationId = 111;//new Random().nextInt();

        Intent intentAction = new Intent(mainActivity, MainActivity.class);
        intentAction.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent open = PendingIntent.getActivity(this, notificationId, intentAction, PendingIntent.FLAG_ONE_SHOT);

        Intent positive = new Intent(this, NotificationReceiver.class);
        positive.putExtra("notiID", notificationId);
        positive.putExtra("cid", getDivNo());
        positive.setAction("ON");
        PendingIntent pIntent_positive = PendingIntent.getBroadcast(this, notificationId, positive, PendingIntent.FLAG_CANCEL_CURRENT);

        Intent negative = new Intent(this, NotificationReceiver.class);
        negative.putExtra("notiID", notificationId);
        negative.putExtra("cid", getDivNo());
        negative.setAction("OFF");
        PendingIntent pIntent_negative = PendingIntent.getBroadcast(this, notificationId, negative, PendingIntent.FLAG_CANCEL_CURRENT);


        Intent xIntent = new Intent(this, NotificationReceiver.class);
        xIntent.putExtra("notiID", notificationId);
        xIntent.setAction("DELETE");
        PendingIntent delete = PendingIntent.getBroadcast(this, notificationId, xIntent, PendingIntent.FLAG_CANCEL_CURRENT);


        Intent receiptIntent = new Intent(this, NotificationReceiver.class);
        receiptIntent.putExtra("notiID", notificationId);
        receiptIntent.setAction("pop_receipt");
        PendingIntent receipt = PendingIntent.getBroadcast(this, notificationId, receiptIntent, PendingIntent.FLAG_CANCEL_CURRENT);


        Intent driveIntent = new Intent(this, NotificationReceiver.class);
        driveIntent.putExtra("notiID", notificationId);
        driveIntent.setAction("pop_drive");
        PendingIntent drive = PendingIntent.getBroadcast(this, notificationId, driveIntent, PendingIntent.FLAG_CANCEL_CURRENT);

        android.support.v4.app.NotificationCompat.Builder notification = new android.support.v4.app.NotificationCompat.Builder(mainActivity);
        notification.setAutoCancel(false);
        notification.setGroup("GROUP_KEY");
        //notification.setContentTitle("블루투스연결된 장비:\n" );
        //notification.setContentText("블루투스 이벤트 장치선택 변경/수정/모니터링");
        notification.setSmallIcon(R.drawable.logo_penut);
        notification.setAutoCancel(false);
        notification.setOngoing(true);

        //notification.setColor(ContextCompat.getColor(mainActivity, colorID));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification.setChannelId("channel_id");
        }
        notification.setPriority(Notification.PRIORITY_HIGH);
        notification.setContentIntent(open);
        //notification.addAction(new NotificationCompat.Action(R.drawable.logo, "켜기", pIntent_positive));
        //notification.addAction(new NotificationCompat.Action(R.drawable.logo, "끄기", pIntent_negative));

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        //mNotificationManager.notify(notificationId, mNotificationManager.build());

        RemoteViews contentview = new RemoteViews(getPackageName(), R.layout.removeview);

        //타이틀 설정
        //contentview.setTextViewText(R.id.title, "관리자\n");
        //contentview.setOnClickPendingIntent(R.id.OnOff, pIntent_positive);
        contentview.setOnClickPendingIntent(R.id.xx, delete);
        notification.setContent(contentview);
        mNotificationManager.notify(notificationId, notification.build());
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadNetwork);
    }

    BroadcastReceiver broadNetwork = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            if (isDataConnected() > 0) {
                PermisionCheck();
            }
        }
    };


    private void permIngtent() {

    }

    private void afterCheck() {
        try {

            JoinWebAsyncTask boardAsyncTask = new JoinWebAsyncTask(MainActivity.this, "getStudyList");
            boardAsyncTask.execute(MainActivity.host, "token=12345&UUID_KEY=" + getDevicesUUID(), "getStudyList");

            Log.d("LOGDA", "UUID = " + getDevicesUUID());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void PermisionCheck() {

        //Log.d("LOGDA", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ PermisionCheck SDK_INT=" + Build.VERSION.SDK_INT + "   Build.VERSION_CODES.M=" + Build.VERSION_CODES.M);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {//마시멜로 미만버전
            afterCheck();
        } else {//마시멜로이상
            //Log.d("LOGDA", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ canDrawOverlays  = " + Settings.canDrawOverlays(mainActivity));

            if (shouldShowRequestPermissionRationale(android.Manifest.permission.READ_EXTERNAL_STORAGE)) {
                permIngtent();
            } else if (shouldShowRequestPermissionRationale(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                permIngtent();
            } else if (shouldShowRequestPermissionRationale(android.Manifest.permission.ACCESS_NETWORK_STATE)) {
                permIngtent();
            } else if (shouldShowRequestPermissionRationale(android.Manifest.permission.ACCESS_COARSE_LOCATION)) {
                permIngtent();
            } else if (shouldShowRequestPermissionRationale(android.Manifest.permission.ACCESS_FINE_LOCATION)) {
                permIngtent();
            } else if (shouldShowRequestPermissionRationale(android.Manifest.permission.CALL_PHONE)) {
                permIngtent();
            } else if (shouldShowRequestPermissionRationale(android.Manifest.permission.READ_PHONE_STATE)) {
                permIngtent();
            } else if (shouldShowRequestPermissionRationale(android.Manifest.permission.READ_SMS)) {
                permIngtent();
            } else {
                //checkPermission();
                Intent intent = new Intent(MainActivity.this, AuthCheckShowActivity.class);
                startActivityForResult(intent, 8888);
            }
        }
    }


    public View.OnClickListener dismis_finish = new View.OnClickListener() {
        public void onClick(View v) {
            dialog.dismiss();
            finish();
        }
    };

    private int isDataConnected() {
        //Log.d("LOGDA", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ isDataConnected ");
        int rs = 0;
        try {

            ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo mobile = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);//데이타 연결
            NetworkInfo wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);//와이파이

            if (mobile.isConnected()) {

                rs = 1;
            } else if (wifi.isConnected()) {

                rs = 2;
            } else if (!mobile.isConnected() && !wifi.isConnected()) {
                if (dialog != null && dialog.isShowing()) dialog.dismiss();
                dialog = new CommonDialog(this, "인터넷 연결 실패 !!\n앱 종료 됩니다.\n인터넷 연결 후 재시도 하세요", "확인", dismis_finish);
                dialog.show();
                rs = 0;
            }

        } catch (Exception e) {
            return 0;
        }

        //Log.d("LOGDA", "네트워크 확인 = " + rs);
        return rs;
    }


    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        if (intent != null) {
            processIntent(intent);
        }
    }

    //TDES des = new TDES();
    private void processIntent(Intent intent) {

    }

    private String getDevicesUUID() {
        final TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        final String tmDevice, tmSerial, androidId;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return null;
        }
        tmDevice = "" + tm.getDeviceId();
        tmSerial = "" + tm.getSimSerialNumber();
        androidId = "" + android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
        UUID deviceUuid = new UUID(androidId.hashCode(), ((long) tmDevice.hashCode() << 32) | tmSerial.hashCode());
        String deviceId = deviceUuid.toString();
        return deviceId;
    }


    private void setupRecyclerView(RecyclerView recyclerView) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(recyclerView.getContext());
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter = new SimpleStringRecyclerViewAdapter(MainActivity.this);

        recyclerView.setAdapter(adapter);
        /*scrollListener = new EndlessRecycleViewScrollListener(linearLayoutManager) {
            @Override
            public void onLoadMore(int page, int totalItemsCount, RecyclerView view) {
                b_more.setVisibility(View.VISIBLE);
            }
        };

        //Adds the scroll listener to RecyclerView
        recyclerView.addOnScrollListener(scrollListener);*/

    }

    public void searchKeyWord(View view) {

    }


    public class SimpleStringRecyclerViewAdapter extends RecyclerView.Adapter<SimpleStringRecyclerViewAdapter.ViewHolder> {

        private final TypedValue mTypedValue = new TypedValue();
        private int mBackground;
        private List<ListVO> mValues;

        public List<ListVO> getMValue() {
            return mValues;
        }

        public void clear() {
            mValues.clear();
        }

        //내부클래스 시작
        public class ViewHolder extends RecyclerView.ViewHolder {

            public final View mView;
            public final TextView idx;
            public final TextView title;
            public final TextView tot_time;
            public final TextView file_name;
            public final TextView scriptYN;
            public final ImageView downYn;
            public final ImageView title_img;
            public final LinearLayout layout;

            public ViewHolder(View view) {
                super(view);
                mView = view;
                idx = (TextView) view.findViewById(R.id.idx);
                title = (TextView) view.findViewById(R.id.title);
                tot_time = (TextView) view.findViewById(R.id.tot_time);
                file_name = (TextView) view.findViewById(R.id.file_name);
                scriptYN = (TextView) view.findViewById(R.id.scriptYN);
                downYn = (ImageView) view.findViewById(R.id.downYn);
                title_img = (ImageView) view.findViewById(R.id.title_img);
                layout = (LinearLayout) view.findViewById(R.id.layout);
            }

           /* @Override
            public String toString() {
                return super.toString() + " '" + shop_name.getText();
            }*/

        }//내부클래스 종료

        public void addItemString(ListVO item) {
            mValues.add(item);
        }

        public SimpleStringRecyclerViewAdapter(Context context) {
            context.getTheme().resolveAttribute(R.attr.selectableItemBackground, mTypedValue, true);
            mBackground = mTypedValue.resourceId;
            mValues = new ArrayList<ListVO>();
        }

        @Override
        public SimpleStringRecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_point_list, parent, false);
            view.setBackgroundResource(mBackground);
            return new SimpleStringRecyclerViewAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final SimpleStringRecyclerViewAdapter.ViewHolder holder, final int position) {
            //holder.title_img.setText(mValues.get(position).getImg_name());
            holder.idx.setText(mValues.get(position).getIdx());
            holder.title.setText(mValues.get(position).getTitle_name());
            holder.file_name.setText(mValues.get(position).getFile_name());
            holder.tot_time.setText(mValues.get(position).getTot_time());
            //holder.downYn.setText(mValues.get(position).getFile_down_yn());

            //북마크
            if (mValues.get(position).getFile_down_yn() != null && mValues.get(position).getFile_down_yn().equals("Y")) {
                Drawable start2 = getResources().getDrawable(R.drawable.star2);
                holder.downYn.setImageDrawable(start2);
            } else {
                Drawable star_empty = getResources().getDrawable(R.drawable.star_empty);
                holder.downYn.setImageDrawable(star_empty);
            }

            holder.scriptYN.setText("(O,0)");

            Glide.with(MainActivity.this)
                    .load(mValues.get(position).getImg_name())
                    .fitCenter()
                    .placeholder(R.drawable.logo_penut)
                    .into(holder.title_img);

            holder.layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(MainActivity.this, PlayerSpeedActivity.class);
                    i.putExtra("uuid", getDevicesUUID());
                    i.putExtra("file_down", mValues.get(position).getFile_down_yn());
                    i.putExtra("file_name", mValues.get(position).getFile_name());
                    i.putExtra("idx", mValues.get(position).getIdx());
                    i.putExtra("tot_time", mValues.get(position).getTot_time());
                    i.putExtra("title_name", mValues.get(position).getTitle_name());
                    i.putExtra("scriptYN", mValues.get(position).getFile_down_yn());

                    i.putExtra("number", "" + position);
                    startActivity(i);
                }
            });


        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }
    }


    @Override
    public void onBackPressed() {
        //finish();
        if (mainActivity != null && mainActivity != null && !mainActivity.isFinishing()) {
            cancelYnDialog = new CommonCancelDialog(mainActivity, dismis_cancel);
            cancelYnDialog.show();
        }
    }

    public View.OnClickListener dismis_cancel = new View.OnClickListener() {
        public void onClick(View v) {
            cancelYnDialog.dismiss();
            finish();
        }
    };

    public void close(View view) {
        finish();
    }


    public String getDivNo() {
        String phoneNum = "";
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                TelephonyManager telManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);

                if (telManager.getSimState() == TelephonyManager.SIM_STATE_ABSENT) {
                    // 유심이 없는 경우
                    phoneNum = "";
                } else {
                    // 유심이 존재하는 경우
                    phoneNum = telManager.getLine1Number();//전화번호
                    if (phoneNum != null) {
                        if (phoneNum.startsWith("+82")) {
                            phoneNum = phoneNum.replace("+82", "0");
                        } else if (phoneNum.startsWith("82")) {
                            phoneNum = phoneNum.replace("82", "0");
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "전화 번호가 없습니다", Toast.LENGTH_LONG).show();
                    }
                }

                return phoneNum;
            } else {
                return "";
            }
        } else {
            if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                TelephonyManager telManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
                if (telManager.getSimState() == TelephonyManager.SIM_STATE_ABSENT) {
                    // 유심이 없는 경우
                    phoneNum = "";
                } else {
                    // 유심이 존재하는 경우
                    phoneNum = telManager.getLine1Number();//전화번호
                    if (phoneNum != null) {
                        if (phoneNum.startsWith("+82")) {
                            phoneNum = phoneNum.replace("+82", "0");
                        } else if (phoneNum.startsWith("82")) {
                            phoneNum = phoneNum.replace("82", "0");
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "전화 번호가 없습니다", Toast.LENGTH_LONG).show();
                    }
                }
            }
            return phoneNum;
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //Log.d("LOGDA", "@@ requestCode=" + requestCode);
        switch (requestCode) {
            case 8888:
                //Log.d("LOGDA", "data intent~~~~~~~ 1003");
                afterCheck();
                break;
        }
    }


}
