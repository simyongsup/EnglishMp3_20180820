/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.android.exoplayer2.demo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.telephony.TelephonyManager;
import android.text.SpannableStringBuilder;
import android.util.Log;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.View.OnTouchListener;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.VO.DetailVO;
import com.google.android.exoplayer2.VO.ListVO;
import com.google.android.exoplayer2.dialog.CommonMusicStopDialog;
import com.google.android.exoplayer2.mediacodec.MediaCodecRenderer.DecoderInitializationException;
import com.google.android.exoplayer2.mediacodec.MediaCodecUtil.DecoderQueryException;
import com.google.android.exoplayer2.menu.MenuListViewAdapter;
import com.google.android.exoplayer2.nw.JoinWebAsyncTask;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.ui.DebugTextViewHelper;
import com.google.android.exoplayer2.ui.PlaybackControlView;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.util.Util;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * An activity that plays media using {@link SimpleExoPlayer}.
 */
public class PlayerSpeedActivity extends Activity implements OnKeyListener, OnTouchListener,
        OnClickListener, ExoPlayer.EventListener, SimpleExoPlayer.VideoListener, IPlayerUI, PlaybackControlView.VisibilityListener {

    public static final String DRM_SCHEME_UUID_EXTRA = "drm_scheme_uuid";
    public static final String DRM_LICENSE_URL = "uri";
    public static final String PREFER_EXTENSION_DECODERS = "prefer_extension_decoders";

    public static final String ACTION_VIEW = "com.google.android.exoplayer.demo.action.VIEW";
    public static final String EXTENSION_EXTRA = "extension";

    public static final String ACTION_VIEW_LIST = "com.google.android.exoplayer.demo.action.VIEW_LIST";
    public static final String URI_LIST_EXTRA = "uri_list";
    public static final String EXTENSION_LIST_EXTRA = "extension_list";
    PlayerSpeedActivity playerSpeedActivity;
    CommonMusicStopDialog cancelYnDialog;
    private static final CookieManager DEFAULT_COOKIE_MANAGER;

    static {
        DEFAULT_COOKIE_MANAGER = new CookieManager();
        DEFAULT_COOKIE_MANAGER.setCookiePolicy(CookiePolicy.ACCEPT_ORIGINAL_SERVER);
    }

    private IPlayer player = new PlayerImp(this);

    private View rootView;
    private LinearLayout debugRootView;
    private LinearLayout bottom1;
    private LinearLayout bottom2;
    private LinearLayout bottom3;
    private LinearLayout bottomAll;


    private TextView debugTextView;
    private Button retryButton;
    private Button repeatFrom;
    private Button repeatOff;
    public LinearLayout slidingPage01;
    private Button repeatChapter;
    private Button repeatOne;
    private Button repeatAll;
    private Button speedUp;
    private Button speedDown;
    private Button speedGo;
    private TextView content;
    private TextView title;
    private Switch scrollYN;
    private WebView webView;
    private ImageView scriptImg;
    private ImageView repeatOnOff;


    private boolean isFirst = true;
    private long beginingPosition;
    private long endingPosition;

    private DebugTextViewHelper debugViewHelper;
    private Spinner spinnerSpeeds;
    private SimpleExoPlayerView simpleExoPlayerView;
    public static Uri uri;
    private ScrollView scrollView;
    private LinearLayout ScrollLinear;

    private static final String TYPE_IMAGE = "image/*";
    private static final int INPUT_FILE_REQUEST_CODE = 1;
    final int DEFINITION = 0;
    final int DEFINITION1 = 1;

    String pre_currentPosition = "";
    String number = "";
    private static int number_int = 0;
    private static int number_before_int = 0;
    private static int number_next_int = 0;
    public static String go = "";
    private static String id = "";
    private static String uuid = "";
    //public ProgressBar loadingBar;

    public ListView menuListview;
    public MenuListViewAdapter menuAdapter;


    private boolean repeatChapterFlag = false;
    private boolean repeatOneFlag = false;
    private boolean repeatAllFlag = false;
    public boolean scrollYNFlag = false;
    List<ListVO> mValues = null;
    private float currentSpeed = 1;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        init();
        //initAfter23();
        //initPre23();

    }

    int bottom2_height = 0;

    private void init() {
        player.onCreate();
        playerSpeedActivity = this;

        if (CookieHandler.getDefault() != DEFAULT_COOKIE_MANAGER) {
            CookieHandler.setDefault(DEFAULT_COOKIE_MANAGER);
        }

        setContentView(R.layout.player_activity);
        rootView = findViewById(R.id.root);
        scrollView = (ScrollView) findViewById(R.id.scrollView);
        slidingPage01 = (LinearLayout) findViewById(R.id.slidingPage01);
        ScrollLinear = (LinearLayout) findViewById(R.id.ScrollLinear);
        webView = (WebView) findViewById(R.id.webView);
        content = (TextView) findViewById(R.id.content);
        title = (TextView) findViewById(R.id.title);
        scriptImg = (ImageView) findViewById(R.id.scriptImg);
        repeatOnOff = (ImageView) findViewById(R.id.repeatOnOff);
        spinnerSpeeds = ((Spinner) findViewById(R.id.spinner_speeds));

        rootView.setOnTouchListener(this);
        rootView.setOnKeyListener(this);

        scrollYN = (Switch) findViewById(R.id.scrollYN);
        scrollYN.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Log.d("LOGDA", "b=" + b);
                if (debugViewHelper != null) {
                    debugViewHelper.scrollYN = b;
                    if (b == false) {
                        setScrollTop();
                    }
                }
            }
        });

        /*repeatOff = (Button) findViewById(R.id.repeatOff);
        repeatOff.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                repeatOneFlag = false;
                repeatAllFlag = false;
                debugViewHelper.setBegingPosition(0);
                debugViewHelper.setEndingPosition(0);

                beginingPosition = 0;
                endingPosition = 0;

                isFirst = true;

                repeatFrom.setBackgroundColor(Color.parseColor("#cccccc"));
                repeatOne.setBackgroundColor(Color.parseColor("#cccccc"));
                repeatAll.setBackgroundColor(Color.parseColor("#cccccc"));
            }
        });*/

        repeatOnOff.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (debugViewHelper.repeatOnOffFlag == true) {
                    debugViewHelper.repeatOnOffFlag = false;
                    Log.d("LOGDA", "반복 OFF");
                    repeatOnOff.setBackgroundResource(R.drawable.rotation_3);

                } else {
                    debugViewHelper.repeatOnOffFlag = true;
                    Log.d("LOGDA", "반복 ON");
                    repeatOnOff.setBackgroundResource(R.drawable.arrow_right);

                    if (debugViewHelper.player.getPlayWhenReady() == false) {
                        player.setPlayWhenReady(true);
                    }
                }

                //checkRepeatChapter();
            }
        });


        //문장반복
        repeatChapter = (Button) findViewById(R.id.repeatChapter);
        repeatChapter.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                //구간반복종료
                //debugViewHelper.repeatTerm = false;
                //repeatFrom.setBackgroundColor(Color.parseColor("#ffffff"));

                String title = repeatChapter.getText().toString();
                //한문장만
                if (title != null && title.equals("전체")) {
                    repeatChapter.setText("문장");
                    //debugViewHelper.chapterFlag = true;
                    debugViewHelper.repeatChapter = true;
                    debugViewHelper.repeatChapterAll = false;

                    checkRepeatChapter();
                    if (debugViewHelper.player.getPlayWhenReady() == false) {
                        player.setPlayWhenReady(true);
                    }
                    //전체문장
                } else if (title != null && title.equals("문장")) {
                    repeatChapter.setText("전체");
                    //debugViewHelper.chapterFlag = false;
                    debugViewHelper.repeatChapter = false;
                    debugViewHelper.repeatChapterAll = true;

                    if (debugViewHelper.player.getPlayWhenReady() == false) {
                        player.setPlayWhenReady(true);
                    }

                    //문장 관련 없음
                } /*else if (title != null && title.equals("전체")) {
                    repeatChapter.setText("문장/전체");
                    debugViewHelper.chapterFlag = false;
                    debugViewHelper.repeatChapter = false;
                    debugViewHelper.repeatChapterAll = false;
                    if (debugViewHelper.player.getPlayWhenReady() == false) {
                        player.setPlayWhenReady(true);
                    }
                }*/
            }
        });

        //
        repeatOne = (Button) findViewById(R.id.repeatOne);
        repeatOne.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                ColorDrawable corItem = (ColorDrawable) repeatOne.getBackground();
                if (corItem.getColor() == Color.RED) {
                    repeatOneFlag = false;
                    repeatOne.setBackgroundColor(Color.parseColor("#ffffff"));
                    repeatAll.setBackgroundColor(Color.parseColor("#ffffff"));

                } else {
                    repeatOneFlag = true;
                    repeatAllFlag = false;
                    repeatOne.setBackgroundColor(Color.RED);
                    repeatAll.setBackgroundColor(Color.parseColor("#ffffff"));
                }

                Log.d("LOGDA_REPEAT", "repeatOneFlag = " + repeatOneFlag);
            }
        });

        //전체반복
        repeatAll = (Button) findViewById(R.id.repeatAll);
        repeatAll.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                //repeatOneFlag = true;
                //debugViewHelper.repeat = false;
                //repeatFrom.setBackgroundColor(Color.parseColor("#cccccc"));

                ColorDrawable corItem = (ColorDrawable) repeatAll.getBackground();
                if (corItem.getColor() == Color.RED) {
                    repeatAllFlag = false;
                    repeatOne.setBackgroundColor(Color.parseColor("#ffffff"));
                    repeatAll.setBackgroundColor(Color.parseColor("#ffffff"));

                } else {
                    repeatOneFlag = false;
                    repeatAllFlag = true;
                    repeatOne.setBackgroundColor(Color.parseColor("#ffffff"));
                    repeatAll.setBackgroundColor(Color.RED);
                }

                Log.d("LOGDA_REPEAT", "repeatAllFlag = " + repeatAllFlag);
            }
        });

        //구간반복
        repeatFrom = (Button) findViewById(R.id.repeatFrom);
        repeatFrom.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ColorDrawable corItem = (ColorDrawable) repeatFrom.getBackground();
                if (corItem.getColor() == Color.YELLOW) {
                    Log.d("LOGDA", "구간 반복 종료구간");
                    endingPosition = player.getCurrentPosition();
                    isFirst = true;

                    debugViewHelper.repeatTerm = true;
                    //repeatOneFlag = false;
                    //repeatAllFlag = false;

                    debugViewHelper.setBegingPosition(beginingPosition);
                    debugViewHelper.setEndingPosition(endingPosition);

                    repeatFrom.setBackgroundColor(Color.RED);


                } else if (corItem.getColor() == Color.RED) {
                    repeatFrom.setBackgroundColor(Color.parseColor("#ffffff"));
                    debugViewHelper.repeatTerm = false;

                } else {
                    Log.d("LOGDA", "구간 반복 시작");
                    beginingPosition = player.getCurrentPosition();
                    isFirst = false;
                    repeatFrom.setBackgroundColor(Color.YELLOW);

                    //문장반복 원복
                    debugViewHelper.repeatChapter = false;
                    repeatChapter.setBackgroundColor(Color.parseColor("#ffffff"));

                }
            }
        });

        speedUp = (Button) findViewById(R.id.speedUp);
        speedUp.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("LOGDA", "currentSpeed = " + String.format("%.1f", currentSpeed));
                currentSpeed = (float) (currentSpeed + 0.1);
                if (currentSpeed >= 2) {
                    currentSpeed = 2;
                }
                Toast.makeText(playerSpeedActivity, "재생속도:" + String.format("%.1f", currentSpeed), Toast.LENGTH_LONG).show();
                player.setSpeed(currentSpeed);
            }
        });

        speedGo = (Button) findViewById(R.id.speedGo);
        speedGo.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("LOGDA", "currentSpeed = " + String.format("%.1f", currentSpeed));
                currentSpeed = 1;
                Toast.makeText(playerSpeedActivity, "재생속도:" + String.format("%.1f", currentSpeed), Toast.LENGTH_LONG).show();
                player.setSpeed(currentSpeed);
            }
        });

        speedDown = (Button) findViewById(R.id.speedDown);
        speedDown.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("LOGDA", "currentSpeed = " + String.format("%.1f", currentSpeed));
                currentSpeed = (float) (currentSpeed - 0.1);
                if (currentSpeed < 0.5) {
                    currentSpeed = (float) 0.5;
                }
                Toast.makeText(playerSpeedActivity, "재생속도:" + String.format("%.1f", currentSpeed), Toast.LENGTH_LONG).show();
                player.setSpeed(currentSpeed);
            }
        });


        final String[] speeds = getResources().getStringArray(R.array.speed_values);
        spinnerSpeeds.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                player.setSpeed(Float.valueOf(speeds[position]));
                currentSpeed = Float.valueOf(speeds[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        debugRootView = (LinearLayout) findViewById(R.id.controls_root);
        bottom1 = (LinearLayout) findViewById(R.id.bottom1);
        bottom2 = (LinearLayout) findViewById(R.id.bottom2);
        bottom3 = (LinearLayout) findViewById(R.id.bottom3);
        bottomAll = (LinearLayout) findViewById(R.id.bottomAll);
        debugTextView = (TextView) findViewById(R.id.debug_text_view);

        retryButton = (Button) findViewById(R.id.retry_button);
        retryButton.setOnClickListener(this);

        spinnerSpeeds.setSelection(2);
        player.setSpeed(1.0f);
        simpleExoPlayerView = ((SimpleExoPlayerView) findViewById(R.id.player_view));
        simpleExoPlayerView.setControllerVisibilityListener(this);
        simpleExoPlayerView.requestFocus();


        menuAdapter = new MenuListViewAdapter();
        menuListview = (ListView) findViewById(R.id.menu_list);
        menuListview.setAdapter(menuAdapter);

        //메뉴 아이템 추가.
        menuAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.text), "글자크기 +", "Account Box Black 36dp");//0
        menuAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.text), "글자크기 -", "Account Box Black 36dp");//0
        //menuAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.out), "퇴근하기", "Account Circle Black 36dp");//1
        listviewClick(menuListview);

        if (getIntent() != null) {
            processIntent(getIntent());
        }
    }

    public int chapterIndex = 0;
    float position = 0;

    private void checkRepeatChapter() {
        position = player.getCurrentPosition();
        for (int i = 0; i < tvArray.length; ++i) {
            tvArray[i].setBackgroundColor(Color.parseColor("#A4A4A4"));
            if (position >= StartTerm[i] && position <= EndTerm[i]) {
                tvArray[i].setBackgroundColor(Color.parseColor("#cccccc"));
                debugViewHelper.scrollToView(tvArray[i], scrollView, 0);
                chapterIndex = i;
                break;
            }
        }
    }


    private static float textSize = 0;

    private void listviewClick(ListView lv) {
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("LOGDA", "textSize = " + textSize);
                //키우기
                if (position == 0) {
                    ++textSize;
                    if (textSize > 25) {
                        textSize = 25;
                    }
                    for (int i = 0; i < tvArray.length; ++i) {
                        tvArray[i].setTextSize((textSize));
                    }

                    Toast.makeText(playerSpeedActivity, "글자크기:" + textSize, Toast.LENGTH_LONG).show();

                    //작게
                } else if (position == 1) {
                    --textSize;
                    if (textSize < 10) {
                        textSize = 10;
                    }
                    for (int i = 0; i < tvArray.length; ++i) {
                        tvArray[i].setTextSize((textSize));
                    }

                    Toast.makeText(playerSpeedActivity, "글자크기:" + textSize, Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    @Override
    public void onNewIntent(Intent intent) {
        //player.resetPosition();

        processIntent(intent);
        setIntent(intent);
    }

    private void processIntent(Intent intent) {

        //id = intent.getStringExtra("idx");
        uuid = intent.getStringExtra("uuid");
        //String title_name = intent.getStringExtra("title_name");
        //String scriptYN = intent.getStringExtra("scriptYN");
        //정열인덱스
        number = intent.getStringExtra("number");
        number_int = Integer.parseInt(number == null ? "0" : number);
        mValues = MainActivity.adapter.getMValue();

        pre_currentPosition = intent.getStringExtra("pre_currentPosition");
        String pre_number_int = intent.getStringExtra("pre_number_int");
        //String pre_idx = intent.getStringExtra("pre_idx");

        if (pre_number_int != null && !pre_number_int.equals("")) {
            Log.d("LOGDA_REPEAT", "onNewIntent current pre_number_int = " + pre_number_int + "  pre_currentPosition = " + pre_currentPosition);
            number_int = Integer.parseInt(pre_number_int == null ? "0" : pre_number_int);
        }

        setGoUrl(mValues.get(number_int));
    }


    public boolean onKeyDown(int keycode, KeyEvent event) {
        switch (keycode) {

            case KeyEvent.KEYCODE_VOLUME_UP:
                player.setPlayWhenReady(false);
                break;

            case KeyEvent.KEYCODE_VOLUME_DOWN:
                player.seek(0);
                break;

            case KeyEvent.KEYCODE_BACK:
                if (playerSpeedActivity != null && playerSpeedActivity != null && !playerSpeedActivity.isFinishing()) {
                    cancelYnDialog = new CommonMusicStopDialog(playerSpeedActivity, dismis_cancel);
                    cancelYnDialog.show();
                }

                //releasePlayer();
                //finish();
                break;

        }
        return true;
    }

/*
    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        File imageFile = File.createTempFile(
                imageFileName,  *//* prefix *//*
                ".jpg",         *//* suffix *//*
                storageDir      *//* directory *//*
        );
        return imageFile;
    }*/


    @Override
    public void onStart() {
        super.onStart();
        Log.d("LOGDA", "onStart");
        //initAfter23();

        if (player == null) {
            Log.d("LOGDA", "player == null");
        } else {
            Log.d("LOGDA", "player != null");
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("LOGDA", "onResume");
        //initPre23();

        /*if (debugViewHelper == null) {
            debugViewHelper = new DebugTextViewHelper(player.getExoPlayer(), debugTextView);
            debugViewHelper.start();
        }*/
    }

    @Override
    public void onCreatePlayer() {
        Log.d("LOGDA_CURRENT", "onCreatePlayer()");
        simpleExoPlayerView.setPlayer(player.getExoPlayer());
    }


    private void initAfter23() {
        if (Util.SDK_INT > 23) {
            initPlayer();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void initPlayer() {
        //Uri uri = Uri.parse("asset:///cf752b1c12ce452b3040cab2f90bc265_h264818000nero_aac32-1.mp4");
        //uri = Uri.parse("http://storage.googleapis.com/exoplayer-test-media-0/play.mp3");
        player.initPlayer(uri);

        //trackSelectionHelper = player.createTrackSelectionHelper();
        debugViewHelper = new DebugTextViewHelper(player.getExoPlayer(), debugTextView, scrollView, playerSpeedActivity);
        //debugViewHelper = new DebugTextViewHelper(player.getExoPlayer(), debugTextView, ScrollLinear, playerSpeedActivity);
        debugViewHelper.start();
        debugViewHelper.scrollYN = true;

        /*if (scrollYN.isChecked()) {
            debugViewHelper.scrollYN = true;
        } else {
            debugViewHelper.scrollYN = false;
        }*/
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void initPre23() {
        if ((Util.SDK_INT <= 23 || !player.hasPlayer())) {
            initPlayer();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            initPlayer();
        } else {
            showToast(R.string.storage_permission_denied);
            finish();
        }
    }

    // OnTouchListener methods

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
            toggleControlsVisibility();
        } else if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
            view.performClick();
        }
        return true;
    }

    // OnKeyListener methods

    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        return keyCode != KeyEvent.KEYCODE_BACK && keyCode != KeyEvent.KEYCODE_ESCAPE && keyCode != KeyEvent.KEYCODE_MENU;
    }

    // OnClickListener methods

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onClick(View view) {
        if (view == retryButton) {
            initPlayer();
        } else if (view.getParent() == debugRootView) {
            //trackSelectionHelper.showSelectionDialog(this, ((Button) view).getText(),
            //player.getTrackInfo(), (int) view.getTag());
        }
    }


    @Override
    public void onLoadingChanged(boolean isLoading) {
        // Do nothing.
    }

    @Override
    public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {

        //Log.d("LOGDA","onPlayerStateChanged playWhenReady="+playWhenReady);
        if (playbackState == ExoPlayer.STATE_ENDED) {
            showControls();
            if (repeatOneFlag) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    player.seek(0);
                    Log.d("LOGDA_REPEAT", "repeatOne= player.seek(0)()");
                }
            } else if (repeatAllFlag) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    Log.d("LOGDA_REPEAT", "repeatAll= setNExtPlay()");
                    setNExtPlay();
                }
            }
        } else if (playbackState == ExoPlayer.STATE_IDLE) {
            if (pre_currentPosition != null && !pre_currentPosition.equals("")) {
                new Handler().postDelayed(new Runnable() {// 1 초 후에 실행
                    @Override
                    public void run() {
                        //if (pre_currentPosition != null && !pre_currentPosition.equals("")) {
                        //Log.d("LOGDA_REPEAT", "initplayer pre_currentPosition seek= " + (Long.parseLong(pre_currentPosition)));
                        player.seek(Long.parseLong(pre_currentPosition == null || pre_currentPosition.equals("") ? "0" : pre_currentPosition));
                        //} else {
                        //  player.seek(0);
                        //}
                        pre_currentPosition = "";
                    }
                }, 500);
            }
        } else if (playbackState == ExoPlayer.STATE_BUFFERING) {
            Log.d("LOGDA_REPEAT", "STATE_BUFFERING= " + ExoPlayer.STATE_BUFFERING);
        }
        updateButtonVisibilities();
    }

    @Override
    public void onTimelineChanged(Timeline timeline, Object manifest) {

    }

    @Override
    public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray
            trackSelections) {

    }

    @SuppressLint("StringFormatInvalid")
    @Override
    public void onPlayerError(ExoPlaybackException e) {
        String errorString = null;
        if (e.type == ExoPlaybackException.TYPE_RENDERER) {
            Exception cause = e.getRendererException();
            if (cause instanceof DecoderInitializationException) {
                // Special case for decoder initialization failures.
                DecoderInitializationException decoderInitializationException =
                        (DecoderInitializationException) cause;
                if (decoderInitializationException.decoderName == null) {
                    if (decoderInitializationException.getCause() instanceof DecoderQueryException) {
                        errorString = getString(R.string.error_querying_decoders);
                    } else if (decoderInitializationException.secureDecoderRequired) {
                        errorString = getString(R.string.error_no_secure_decoder,
                                decoderInitializationException.mimeType);
                    } else {
                        errorString = getString(R.string.error_no_decoder,
                                decoderInitializationException.mimeType);
                    }
                } else {
                    errorString = getString(R.string.error_instantiating_decoder,
                            decoderInitializationException.decoderName);
                }
            }
        }
        if (errorString != null) {
            showToast(errorString);
        }
        player.onError();
        updateButtonVisibilities();
        showControls();
    }

    @Override
    public void onPositionDiscontinuity() {

    }

    // SimpleExoPlayer.VideoListener implementation

    @Override
    public void onVideoSizeChanged(int width, int height, int unappliedRotationDegrees,
                                   float pixelWidthAspectRatio) {
    }

    @Override
    public void onRenderedFirstFrame() {

    }

    // User controls

    public void updateButtonVisibilities() {
        debugRootView.removeAllViews();

        //retryButton.setVisibility(player.isMediaNeddSource() ? View.VISIBLE : View.GONE);
        //debugRootView.addView(retryButton);

        if (!player.hasPlayer()) {
            return;
        }
    }

    private void toggleControlsVisibility() {

    }

    private void showControls() {
        debugRootView.setVisibility(View.VISIBLE);
    }

    public void showToast(int messageId) {
        showToast(getString(messageId));
    }

    public void showToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
    }


    public void releasePlayer() {
        if (player.hasPlayer()) {
            Log.d("LOGDA", "player.hasPlayer()");
            player.realReleasePlayer();
            debugViewHelper.stop();
            debugViewHelper = null;
        } else {
            Log.d("LOGDA", "!player.hasPlayer()");
        }
    }

    @Override
    public Activity getContext() {
        return this;
    }

    @Override
    public void onVisibilityChange(int visibility) {
        debugRootView.setVisibility(visibility);
    }


    @Override
    public void onPause() {
        super.onPause();
        Log.d("LOGDA", "onPause");
        //releasePre23();
    }

    public long currentPosition = 0;

    @Override
    public void onStop() {
        super.onStop();

        //releaseAfter23();
    }


    private void releasePre23() {
        if (Util.SDK_INT <= 23) {
            releasePlayer();
        }
    }


    private void releaseAfter23() {
        if (Util.SDK_INT > 23) {
            releasePlayer();
        }
    }


    public View.OnClickListener dismis_cancel = new View.OnClickListener() {
        public void onClick(View v) {
            cancelYnDialog.dismiss();
            releasePlayer();
            finish();
        }
    };

    public void goBack(View view) {
        releasePlayer();
        finish();
    }

    public static boolean rotation;

    public void rotation(View view) {
        if (rotation) {
            this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            rotation = false;
        } else {
            this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            rotation = true;
        }
    }

    Dialog m_loadingDialog = null;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void setNExtPlay() {
        /*List<ListVO> list = MainActivity.adapter.getMValue();
        ++number_int;

        if (number_int > list.size() - 1) {
            number_int = 0;
        }

        ListVO vo = list.get(number_int);
        showLoadingBar();

        debugViewHelper.repeatChapter = false;
        debugViewHelper.repeatTerm = false;
        repeatFrom.setBackgroundColor(Color.parseColor("#ffffff"));
        repeatChapter.setBackgroundColor(Color.parseColor("#ffffff"));
        setGoUrl(vo);
        //initPlayer();*/
        Log.d("LOGDA_REPEAT", "setNExtPlay number_int = " + number_int);

        debugViewHelper.goToNext();
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void setPrePlay() {
        List<ListVO> list = MainActivity.adapter.getMValue();
        /*--number_int;

        if (number_int < 0) {
            number_int = list.size() - 1;
        }

        ListVO vo = list.get(number_int);
        showLoadingBar();

        debugViewHelper.repeatChapter = false;
        debugViewHelper.repeatTerm = false;
        repeatFrom.setBackgroundColor(Color.parseColor("#ffffff"));
        repeatChapter.setBackgroundColor(Color.parseColor("#ffffff"));
        setGoUrl(vo);*/
        //initPlayer();
        Log.d("LOGDA", "number_int = " + number_int);

        debugViewHelper.goToPre();

    }


    public void goToLastSentence() {
        debugViewHelper.goToLast();
    }


    public void goToFirst() {
        debugViewHelper.goToFirst();
    }


    //상세 URL
    String host = "http://ilove14.cafe24.com/ESTD/ContentsDetail.php";

    private void setGoUrl(ListVO vo) {
        Log.d("LOGDA_REPEAT", "setGoUrl number_int = " + number_int);

        getDetail(vo.getIdx());
        releasePlayer();
        fileCheckAndDownLoad(vo.getIdx(), vo.getFile_name());

        title.setText(vo.getTitle_name());
        if (vo.getFile_down_yn() != null && vo.getFile_down_yn().equals("Y")) {
            Drawable start2 = getResources().getDrawable(R.drawable.star2);
            scriptImg.setImageDrawable(start2);
        } else {
            Drawable star_empty = getResources().getDrawable(R.drawable.star_empty);
            scriptImg.setImageDrawable(star_empty);
        }
    }

    private void getDetail(String idx) {
        Log.d("LOGDA_REPEAT", "getDetail idx = " + idx);
        JoinWebAsyncTask boardAsyncTask = new JoinWebAsyncTask(PlayerSpeedActivity.this, "getStudySentence");
        boardAsyncTask.execute(host, "token=12345&ID=" + idx + "&UUID_KEY=" + getDevicesUUID(), "getStudySentence");
    }


    public void fileCheckAndDownLoad(String idx, String file_name) {
        Log.d("LOGDA_REPEAT", "fileCheckAndDownLoad number_int = " + number_int + " idx=" + idx + " file_name=" + file_name);
        JoinWebAsyncTask boardAsyncTask2 = new JoinWebAsyncTask(PlayerSpeedActivity.this, "getFileDownLoad");
        boardAsyncTask2.execute("getFileDownLoad", idx, file_name);
    }

    private ProgressDialog mDlg;
    public final Handler progressDlg = new Handler() {
        public void handleMessage(Message msg) {
            mDlg = new ProgressDialog(playerSpeedActivity);
            mDlg.setCancelable(false);
            mDlg.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            mDlg.setMessage("다운로드중 입니다.");
            mDlg.show();
        }
    };

    public final Handler progressDlgUpdate = new Handler() {
        public void handleMessage(Message msg) {
            if (mDlg != null && mDlg.isShowing())
                mDlg.setProgress(msg.what);
        }
    };


    public final Handler progressDlgFinish = new Handler() {
        public void handleMessage(Message msg) {
            if (mDlg != null && mDlg.isShowing()) {
                mDlg.dismiss();
                //Toast.makeText(playerSpeedActivity, "다운로드 완료", Toast.LENGTH_LONG).show();
            }

            if (m_loadingDialog != null && m_loadingDialog.isShowing()) {
                m_loadingDialog.dismiss();
                m_loadingDialog = null;
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                initPlayer();
            }
        }
    };


    public String getDevicesUUID() {
        final TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        final String tmDevice, tmSerial, androidId;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return null;
        }
        tmDevice = "" + tm.getDeviceId();
        tmSerial = "" + tm.getSimSerialNumber();
        androidId = "" + android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
        UUID deviceUuid = new UUID(androidId.hashCode(), ((long) tmDevice.hashCode() << 32) | tmSerial.hashCode());
        String deviceId = deviceUuid.toString();
        return deviceId;
    }

    SpannableStringBuilder ssb = null;
    public TextView[] tvArray = null;
    public int[] StartTerm = null;
    public int[] EndTerm = null;
    int count_tv = 0;

    public void setDetailList(ArrayList<DetailVO> list) {

        tvArray = null;
        StartTerm = null;
        EndTerm = null;
        count_tv = 0;

        if (list != null && list.size() > 0) {
            tvArray = new TextView[list.size()];
            StartTerm = new int[list.size()];
            EndTerm = new int[list.size()];
            count_tv = list.size();
            ScrollLinear.removeAllViews();
            Log.d("LOGDA_REPEAT", "setDetailList list.size() = " + list.size());
            for (int i = 0; i < list.size(); ++i) {
                DetailVO vo = list.get(i);
                TextView tv = new TextView(this);
                View v = new View(this);

                tv.setText(vo.getForeign_sentence());
                tv.setTextIsSelectable(true);
                //scrollView.addView(tv);

                tv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                tv.setPadding(15, 20, 15, 20);

                v.setBackgroundColor(Color.parseColor("#cccccc"));
                v.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1));

                setLongClick(tv);

                tvArray[i] = tv;
                if (textSize == 0) {
                    textSize = 20;
                    tvArray[i].setTextSize(textSize);
                } else {
                    tvArray[i].setTextSize(textSize);
                }

                StartTerm[i] = Integer.parseInt(vo.getStart_loc_msec());
                EndTerm[i] = Integer.parseInt(vo.getEnd_loc_msec());
                ScrollLinear.addView(tv);
                ScrollLinear.addView(v);

            /*if (i == 0) {
                content.setText("\n\n\n" + vo.getForeign_sentence());
            } else {
                content.append("\n" + vo.getForeign_sentence());
            }*/
                //Log.d("LOGDA", " id=" + vo.getIdx() + ", seq =" + vo.getOrder_seq() + " file_name = " + vo.getFile_name() + "  , content = " + vo.getForeign_sentence());
            }
        }

        /*
        content.append("\n\n\n");
        ssb = new SpannableStringBuilder(content.getText().toString());
        debugViewHelper.setSsb(ssb);
        */

        /*
        Log.d("LOGDA", "getLineHeight = " + content.getLineHeight());
        Log.d("LOGDA", "getHeight = " + content.getHeight());
        Log.d("LOGDA", "getMeasuredHeight = " + content.getMeasuredHeight());
        Log.d("LOGDA", "scrollView getHeight = " + scrollView.getHeight());
        Log.d("LOGDA", "scrollView getMeasuredHeight = " + scrollView.getMeasuredHeight());
        */
    }

    private void setLongClick(final TextView tv) {
        tv.setCustomSelectionActionModeCallback(new ActionMode.Callback() {

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                // Remove the "select all" option
                menu.removeItem(android.R.id.selectAll);
                // Remove the "cut" option
                menu.removeItem(android.R.id.cut);
                // Remove the "copy all" option
                menu.removeItem(android.R.id.copy);
                return true;
            }

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                // Called when action mode is first created. The menu supplied
                // will be used to generate action buttons for the action mode

                // Here is an example MenuItem
                menu.add(0, DEFINITION, 0, "검색").setIcon(R.drawable.logo_penut);
                //menu.add(1, DEFINITION1, 1, "복사").setIcon(R.drawable.ic_launcher);
                return true;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {

            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                switch (item.getItemId()) {
                    //검색
                    case DEFINITION:
                        int min = 0;
                        int max = tv.getText().length();
                        if (tv.isFocused()) {
                            final int selStart = tv.getSelectionStart();
                            final int selEnd = tv.getSelectionEnd();

                            min = Math.max(0, Math.min(selStart, selEnd));
                            max = Math.max(0, Math.max(selStart, selEnd));
                        }
                        // Perform your definition lookup with the selected text
                        final CharSequence selectedText = tv.getText().subSequence(min, max);

                        Log.d("LOGDA", "CharSequence  검색 = " + selectedText);
                        // Finish and close the ActionMode
                        Intent intents = new Intent(getApplicationContext(), PopActivity.class);
                        intents.putExtra("qr", "" + selectedText);
                        startActivity(intents);

                        mode.finish();
                        return true;

                    case DEFINITION1:
                        int min1 = 0;
                        int max1 = tv.getText().length();
                        if (tv.isFocused()) {
                            final int selStart = tv.getSelectionStart();
                            final int selEnd = tv.getSelectionEnd();

                            min = Math.max(0, Math.min(selStart, selEnd));
                            max = Math.max(0, Math.max(selStart, selEnd));
                        }
                        // Perform your definition lookup with the selected text
                        final CharSequence selectedText1 = tv.getText().subSequence(min1, max1);
                        Log.d("LOGDA", "CharSequence  복사 = " + selectedText1);
                        mode.finish();
                        return true;

                    default:
                        break;
                }
                return false;
            }
        });
    }

    public SpannableStringBuilder getSsb() {
        return ssb;
    }

    public int getTextViewLength() {
        if (content != null && content.getText() != null) {
            return content.getText().length();
        } else {
            return 0;
        }
    }

    public int getScrollViewHeight() {
        int y = content.getHeight();
        return y;
    }


    public TextView getContentTextView() {
        return content;
    }

    public void setScrollTop() {
        for (int i = 0; i < tvArray.length; ++i) {
            tvArray[i].setBackgroundColor(Color.parseColor("#A4A4A4"));
        }
        debugViewHelper.scrollToView(tvArray[0], scrollView, 0);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        setCurrentData();
        releasePlayer();
    }

    private void setCurrentData() {

        Log.d("LOGDA_CURRENT", "setCurrentData current postion = " + currentPosition + "  number_int = " + number_int);

        SharedPreferences sf = getSharedPreferences("EnglishMp3CurrentData", 0);
        SharedPreferences.Editor editor = sf.edit();//저장하려면 editor가 필요
        editor.putString("currentPosition", "" + currentPosition); // 입력
        editor.putString("idx", "" + mValues.get(number_int).getIdx()); // 입력
        editor.putString("number_int", "" + number_int); // 입력
        editor.commit(); // 파일에 최종 반영함

    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        //setContentView(R.layout.player_activity);
        //init();
        //player.seek(currentPosition);

        Log.d("LOGDA_ROTATION", "onConfigurationChanged");
    }


    private void showLoadingBar() {
        m_loadingDialog = new Dialog(playerSpeedActivity, R.style.custom_loading);
        //프로그레스를 생성하자
        ProgressBar pb = new ProgressBar(playerSpeedActivity);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        //프로그래스를 다이얼로그에 포함하자
        m_loadingDialog.setContentView(pb, params);
        m_loadingDialog.setCancelable(false);
        m_loadingDialog.show();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        bottom2 = (LinearLayout) this.findViewById(R.id.bottom2);
        bottom2_height = bottom2.getHeight();
        Log.w("bottom2_height", "onWindowFocusChanged = " + String.valueOf(bottom2.getHeight()));
        Log.w("bottom2_height", "getMeasuredHeight = " + String.valueOf(bottom2.getMeasuredHeight()));
    }

    public void openUnderBar(View view) {
        if (bottomAll.getVisibility() == View.VISIBLE) {
            bottomAll.setVisibility(View.GONE);
            bottom2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, bottom2_height / 4));
        } else {
            bottomAll.setVisibility(View.VISIBLE);
            bottom2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, bottom2_height));
        }

    }

    boolean isPageOpen = false;

    public void menuManager(View view) {
        if (isPageOpen) {
            //애니메이션 시작
            slidingPage01.setVisibility(View.GONE);
            //slidingPage01.startAnimation(translateRightAnim);
            isPageOpen = false;
        }
        //열기
        else {
            slidingPage01.setVisibility(View.VISIBLE);
            //slidingPage01.startAnimation(translateLeftAnim);
            isPageOpen = true;
        }
    }

}
